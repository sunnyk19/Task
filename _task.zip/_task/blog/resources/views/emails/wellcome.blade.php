<x-mail::message>
   # hello ${} , 
#"HAPPY DEWALI HAVE GREATE AND WONDERFULL,,,,,,,,,,,,,,,,,,,"

I would likethankyou to reading this mail...........

<x-mail::button :url="''">
Visit Again
</x-mail::button>

Thanks,<br>
{{ config('app.name') }}
</x-mail::message>
