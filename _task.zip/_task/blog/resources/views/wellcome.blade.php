<x-mail::message>
   @foreach($users as $user)
   # email from sunny kalaskar 
   #hello {{$user['fname']}}
#"HAPPY DEWALI HAVE GREATE AND WONDERFULL,,,,,,,,,,,,,,,,,,,"

I would likethankyou to reading this mail...........
@endforeach
<x-mail::button :url="''">
Visit Again
</x-mail::button>

Thanks,<br>
{{ config('app.name') }}
</x-mail::message>
