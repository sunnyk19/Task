<?php

namespace App\Http\Controllers;

use App\Mail\WellcomeMail;
use Blade;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;



class MailController extends Controller
{
   
    public function sendEmail(Request  $req ){

      $users= $req->input();
        
        $recieverMailAddress="sunnykalaskar19@gmail.com";

        Mail::to($recieverMailAddress)->send( new WellcomeMail());
        
        return view('Wellcome'.['users'=>$users]);
    }
}
