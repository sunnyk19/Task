 As per Guideline design UI Form Using html css
 Affter submit the data call the controller 
 Single method we get data as well as send the mail withtamplate
 mail send only mailgun users